function initHome(data, source) {
  setText('home-career-count', data.length.toLocaleString('en-AU'));
  setText('home-category-count', unique(data,'category').length.toLocaleString('en-AU'));
  const positiveOutlook = data.filter(d => d.projected != null && d.projected > 0).length;
  setText('home-positive-count', positiveOutlook.toLocaleString('en-AU'));
  showDemoNotice(source);
}

function careerCard(d) {
  return `<article class="career-card">
    <div class="career-card-top"><div><span class="card-kicker">${d.category}</span><h2>${d.occupation}</h2></div><span class="group-chip" title="${format.major(d.major)}">${d.major || '—'}</span></div>
    <p class="career-category">${format.major(d.major)}</p>
    <div class="career-metrics">
      <div class="career-metric"><span>Employment</span><strong>${format.employment(d.employment)}</strong></div>
      <div class="career-metric"><span>3-year change</span><strong class="${tone(d.changePct)}">${format.percent(d.changePct)}</strong></div>
      <div class="career-metric"><span>Skill level</span><strong>${d.skill ?? '—'}</strong></div>
      <div class="career-metric"><span>Outlook to 2030</span><strong class="${tone(d.projected)}">${format.percent(d.projected)}</strong></div>
    </div>
    <div class="career-card-foot"><span>Earnings: ${d.earnings || 'N/A'}</span><span>${d.unemployment || 'N/A'} unemployment</span></div>
  </article>`;
}

function initExplorer(data, source) {
  showDemoNotice(source);
  const search = qs('career-search'), category = qs('category-filter'), skill = qs('skill-filter'), earnings = qs('earnings-filter'), sort = qs('sort-filter'), results = qs('career-results');
  addOptions(category, unique(data,'category'), 'All career fields');
  const params = new URLSearchParams(location.search);
  if (params.get('q')) search.value = params.get('q');
  if (params.get('skill')) skill.value = params.get('skill');
  function render() {
    let list = data.filter(d => (!search.value || d.occupation.toLowerCase().includes(search.value.toLowerCase())) && (!category.value || d.category === category.value) && (!skill.value || String(d.skill) === skill.value) && (!earnings.value || d.earnings === earnings.value));
    const s = sort.value;
    if (s === 'employment') list.sort((a,b)=>(b.employment??-Infinity)-(a.employment??-Infinity));
    else if (s === 'growth') list.sort((a,b)=>(b.changePct??-Infinity)-(a.changePct??-Infinity));
    else if (s === 'outlook') list.sort((a,b)=>(b.projected??-Infinity)-(a.projected??-Infinity));
    else list.sort((a,b)=>a.occupation.localeCompare(b.occupation));
    setText('result-count', list.length);
    results.innerHTML = list.length ? list.slice(0,60).map(careerCard).join('') : '<div class="compare-empty">No occupations match those filters. Try changing one or more selections.</div>';
  }
  [search,category,skill,earnings,sort].forEach(el => el.addEventListener(el.tagName === 'INPUT' ? 'input' : 'change', render));
  qs('reset-filters').addEventListener('click', () => { search.value=''; category.value=''; skill.value=''; earnings.value=''; sort.value='name'; render(); });
  render();
}

function initContact() {
  const form=qs('feedback-form'); if(!form)return;
  form.addEventListener('submit', event=>{event.preventDefault(); if(!form.checkValidity()){form.reportValidity();return;} const status=qs('form-status'); status.hidden=false; status.textContent='Thank you. This prototype has validated your feedback, but no information has been sent or permanently stored.'; form.reset(); status.focus();});
}

async function start() {
  const page = document.body.dataset.page;
  if (page === 'contact') { initContact(); return; }
  if (page === 'about') return;
  if (!page) return;
  try {
    const { data, source } = await CareerData.load();
    if (!data.length) throw new Error('No occupation records were recognised.');
    if (page === 'home') initHome(data, source);
    if (page === 'explorer') initExplorer(data, source);
  } catch (error) {
    const status = qs('data-status');
    if (status) {
      status.textContent = 'The occupation dataset could not be loaded. Run the website through a local web server (for example VS Code Live Server) and confirm the CSV is in the data folder.';
      status.classList.add('is-visible');
    }
    console.error(error);
  }
}

document.addEventListener('DOMContentLoaded', start);
